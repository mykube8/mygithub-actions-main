def buildWithGradle() {
    sh './gradlew build' // Command to execute Gradle build
}
