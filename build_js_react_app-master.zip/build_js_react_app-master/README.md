# CICD
This repository contains the blueprints to setup CICD pipelines for different type of workloads
