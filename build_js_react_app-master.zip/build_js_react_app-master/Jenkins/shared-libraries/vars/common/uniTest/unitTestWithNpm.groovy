def unitTest() {
    def unitTestWithNpm = new org.common.unitTest.UnitTestWithNpm()
    unitTestWithNpm.uniTest()
}
