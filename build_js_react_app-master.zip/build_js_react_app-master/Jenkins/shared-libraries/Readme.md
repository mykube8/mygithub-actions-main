This repository contains scripts and templates for setting up a Jenkins pipeline ,leveraging Jenkins Shared Libraries.


 **Shared Library Scripts**:
   - Utilize the shared library scripts  in pipeline please refer Readme-using-Jenkins-Shared-Libraries.md.

## Files
- **src**: Dsl scripts if any customization we can add here.
- **vars**: Commonly used and less customization DSL Scripts.
- Please refer for shared librarires Readme-using-Jenkins-Shared-Libraries.md


  


