## Usage
To generate Jenkins pipeline jobs for projects and manage deployments, reuse the templates provided in this repository.

pipeline-templates: Stores reusable pipeline templates defining configurations for Jenkins pipelines
1. **Seed Job and Template**:
   Follow the instructions outlined in the Jenkins/seed-job/Readme-using-seed-templates-Jenkins-Shared-Libraries.md file to utilize the seed job and templates effectively.
