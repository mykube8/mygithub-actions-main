package edu.pes.recipes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
