## Prometheus Observability Stack Using Docker 


![image](https://github.com/techiescamp/devops-projects/assets/106984297/6a9f9d90-e56f-4038-82c7-e8eae29d8bcf)


## Project Documentation.

Refer [Setting Up Prometheus Observability Stack](https://devopscube.com/setup-prometheus-using-docker/) for the entire setup walkthrough.

