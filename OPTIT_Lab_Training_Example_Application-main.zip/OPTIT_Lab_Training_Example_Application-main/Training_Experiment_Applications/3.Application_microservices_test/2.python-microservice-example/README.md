
# Microservice communication with RabbitMQ
