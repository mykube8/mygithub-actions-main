# maven
use this to learn maven build

step1:install maven 
step2:build the hava application using maven command mvn build
