package in.optit.optitlabservice;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OptitLabServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
