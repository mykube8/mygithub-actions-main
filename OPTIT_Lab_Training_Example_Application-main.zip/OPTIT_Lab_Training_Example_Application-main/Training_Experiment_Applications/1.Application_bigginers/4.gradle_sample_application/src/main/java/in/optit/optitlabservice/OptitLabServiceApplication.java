package in.optit.optitlabservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OptitLabServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OptitLabServiceApplication.class, args);
	}

}
