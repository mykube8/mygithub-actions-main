package com.mycompany.app;

/**
 * Firstmaven!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Welcome to OptITLab" );
    }
}
