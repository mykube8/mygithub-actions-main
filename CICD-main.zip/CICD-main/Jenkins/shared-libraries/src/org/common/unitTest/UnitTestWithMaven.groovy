package org.common.unitTest

def unitTest() {
    echo 'Unit test with Maven...'
    sh 'mvn test'
}

return this
