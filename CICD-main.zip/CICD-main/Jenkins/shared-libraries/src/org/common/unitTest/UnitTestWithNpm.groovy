package org.common.unitTest

def unitTest() {
    echo 'Unit test with npm...'
    sh 'npm test'
}

return this
