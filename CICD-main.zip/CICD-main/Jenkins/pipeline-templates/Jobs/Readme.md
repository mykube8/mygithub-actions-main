**Steps to create the job using config.xml:**

  - Create the directory named **"gradle"** inside **/var/lib/jenkins/jobs**. Here, **"gradle"** represents the job name.
  - Rename the file **1_Java_Gradle_Build.xml** to **config.xml**.
  - Copy **config.xml** to **/var/lib/jenkins/jobs/gradle**.
  - Restart the Jenkins service.
